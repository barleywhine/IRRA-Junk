Developer change log should contain an entry for each release/tag. Each entry should include the new tag version
according to [SemVer](http://semver.org/), the date the tag was created, each JIRA issue which work was done against,
and a summary of the work completed.

The format for an entry is as follows:

```markdown
* 1.0.0 (2014-10-30)
    * ABC-123
        * _Major_: description of the major change. Note the upper case letter 'M' in Major
        * _minor_: description of the minor change. Note the lower case letter 'm' in minor
        * _patch_: description of the patch change.
```

Consult the git commit log for complete details of a release/tag.

# Change log (most recent first)

* NEXT
  * SRE-1063:
    * _minor_: Runbook for DynamoDB throttle/underprovisioning alarms
  * WS-####
    * _minor_:
  * CAB-307:
    * Update gateway build and deploy instructions to mention cody and mohamed for access
  * SRE-953:
    * _patch_: Update rolling rollback procedure instructions.
  * SRE-791:
    * _minor_: Add instructions to build and deployt the Gateway (dogfooding) ECS Cluster
  * NOREF:
    * _major_: Remove procedures from runbook and enable service with mkdocs
  * SRE-703:
    * _patch_: Update instructions for domain worker termination resolution
  * SRE-517:
    * _minor_: Document AWS role switching
  * _patch_: Fix formatting
  * _minor_: Add fortigate user instructions
  * _minor_: Add doc for manual IQ scanning using Nexus
  * SRE-429:
    * _minor_: add procedural doc for inbound proxy EIP replacement
  * _minor_: Add instructions for viewing indexing activity via cURL for Cloudant
  * _patch_: Fix typo
  * _minor_: Add instructions about purging Domain Refresh Queue in SQS
    * _minor_: table of contents generator
  * WS-6055
    * _minor_: Add note about Domain Worker Max Message Age
  * WS-5629
    * _minor_: Add new ELK stack general information
  * WS-5371
    * _minor_: Add new ELK stack output outage scenarios
  * WS-5296
    * _minor_: Add build/deploy and emergency rollback entries
  * WS-5157
    * _minor_: Add Logstash CPU alarm entry
  * WS-4703
    * _minor_: Initial take on formatting runbook (playbook) for Ops
