# 2FA Setup

## Summary

This process walks through generating a TOTP based 2FA token and updating the
bastion host role to pick it up.  It does not cover setting up an authenticator
application since the software in use is a user preference.

## Prerequisites

* A local clone of the [devops-ansible](https://github.com/virtru/devops-ansible)
* Access to the appropriate "Ansible Vault" secret in 1Password

## Procedure

This procedure has three steps:
1. Generating a TOTP token
1. Updating ansible
1. Setting up your 2FA application

### Generating a TOTP Token

For this, you'll need to have libpam-google-authenticator.  On OSX, you can
install this by running `brew install google-authenticator-libpam`.  After that
run `google-authenticator -t -l 'Virtru Bastion Servers'`.  That will output
the following:

* A link to a QR code
* A QR code on your terminal
* A secret key
* A verification code
* Five scratch codes

You can use the link, the QR code or the secret key with your authenticator
application.  For the next step, we only need the secret key.

#### Updating Ansible

1. In your clone of the [devops-ansible](https://github.com/virtru/devops-ansible),
   navigate to `roles/common/defaults`
1. Using `ansible-vault` edit the `user_tokens.yml` file
    * If your username is already in the list, replace the empty string with the
      secret key from the previous step
    * If your username is not already in the list, add it and provide the secret
      key from the previous step as the value
1. Commit your changes
1. Now either wait for the next base AMI nightly build and then redeploy the
   bastion hosts (using the buildkite pipeline) or kick off a base AMI build
   and redeploy the bastions when that completes

### Setting Up Your 2FA Application

There are a number of different applications that can manage TOTP based tokens
and the instructions for each are going to be different.  In general, most
seem to support either using a camera to read the generated QR code or let you
manually enter the secret key and many support both.  Follow the insructions
for your preferred application.

## Verification

When you connect to the bastion servers, it should prompt you give you a
`Verification code:` prompt and when you provide the correct key, log you
in.
