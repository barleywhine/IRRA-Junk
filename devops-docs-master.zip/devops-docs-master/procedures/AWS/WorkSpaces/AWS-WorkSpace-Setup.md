# AWS WorkSpace Setup

## Summary

This document describes the process for setting up an Amazon WorkSpace from the
AWS web console.

## Prerequisites

* AWS console access

## Procedure

This is pretty simple but takes a little while.  There are also two paths,
after login:
1. Setting up the first workspace
1. Setting up additional workspaces

Before the first workspace is built, there needs to be a directory setup.
Amazon does this behind the scenes for you, when you setup the first WorkSpace.
Because of this, the workflow is slightly different.  Instructions for each
flow are below.

### Login

1. Login to the console
    * If using MARS, switch to the appropriate role/account
1. Click on the "Services" link in the upper left
1. In the "Desktop & App Streaming" section, click on "WorkSpaces"

#### The First WorkSpace

1. Click on the "Get Started Now" button
1. Click on the "Launch" button to the right of the "Quick Setup" block
1. On the "Get Started with Amazon WorkSpaces" enter user information and
   select the appropriate bundle
1. Click on "Launch Workspaces" button
1. Click on "View the WorkSpaces Console" button
1. Click on the "Directories" link on the left hand side
1. Click the checkbox for the directory and then click the "Actions" button and
   select "Update Details"
1. Click the "Access Control Options" link and check the "Web Access" checkbox
   in the "Other Platforms" section
1. Click the "Update and Exit" button

#### Additional WorkSpaces

1. Click on "Launch Workspaces"
1. Click the "Next Step" button
    * Leave the preselected directory
1. Enter user information and click the "Create Users" button OR find an
   existing user in the directory and click "Add Selected"
1. Click the "Next Step" button at the bottom
1. Leave the defaults on the next screen and click the "Next Step" button at
   the bottom
1. Click the "Launch Workspaces" button on the next screen

## Verification

Once the WorkSpace shows as active, contact the user and make sure they have an
email from Amazon.  The email should have a subject of "Your Amazon WorkSpace"
and will contain a registration code.  Verify they have access and you're done.
