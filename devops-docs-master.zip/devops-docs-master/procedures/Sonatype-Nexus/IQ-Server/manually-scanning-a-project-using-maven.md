## Summary

This document describes the process for running an IQ scan against a Java project without going through a full setup of th
Nexus software.  We'll use a docker container and maven to install the IQ server and run the scan.

## Prerequisites

* A JDK (Oracle or Open)
* Maven
* Docker
* A Nexus license file
* [Nexus IQ Sample Policy Set](https://books.sonatype.com/sonatype-clm-book/1.31/resources/Sonatype-Sample-Policy-Set-1.22.json "Nexus IQ Sample Policy Set")
* Local copy of the Java project and a propely setup pom.xml

## Procedure

This procedure is broken up into three parts:
1. Setup the docker container
1. Configure the Nexus IQ server
1. Run the scan

### Docker Container Setup

1. Create a Dockerfile with the following:

        FROM ubuntu:latest
        EXPOSE 8070

        RUN apt-get update \
            && DEBIAN_FRONTEND=noninteractive apt-get install -y \
                default-jre \
            && rm -rf /var/lib/apt/lists/*

        ENV JAVA_HOME /usr/lib/jvm/java-1.8.0-openjdk-amd64/jre

        WORKDIR /root
        ADD https://download.sonatype.com/clm/server/nexus-iq-server-1.31.0-01-bundle.tar.gz /root

        CMD ["/root/demo.sh"]
1. Build the container from the dockerfile:

        docker build . -t iq-server:latest

1. Run the container:
        docker run --publish 8070:8070 -it iq-server

### Configure the Server

1. Login to http://localhost:8070/
    * username: admin
    * password: admin123
1. Click the "Install License" button and upload the license file, accepting the EULA
1. Click the "Organization & Policies" icon in the top menu bar (three boxes)
1. Click the "New Organization" button in the sidebar on the left
    * Enter "Virtru" for the "Organization Name" (this is arbitrary and you can pick whatever you want)
1. To the right of your application name, in the center pane, click the "Actions" link and select "Import Policies"
    * Select the Sample Policy Set from the link in the prerequisites and click "Import"
1. In the left sidebar, under the new organization name, click the "New Application" button
1. Pick an Application Name and Id
    * These can be the same and you'll use the Application Id when running the scan

### Run the Scan

In order to run the scan, you'll need to correctly configure your Java project environment.  The [smtp-proxy](https://github.com/virtru/smtp-proxy) project will be used for this example.

1. Clone [smtp-proxy](https://github.com/virtru/smtp-proxy) repository
1. Update [the virtru-maven](https://github.com/virtru/virtru-maven) submodule from within the clone
1. Modify smtp-proxy/pom.xml to point to the local path of the virtru-maven submodule

        --- a/smtp-proxy/pom.xml
        +++ b/smtp-proxy/pom.xml
        @@ -25,7 +25,7 @@
                 <repository>
                     <id>git-virtru</id>
                     <name>Virtru's Git based repo</name>
        -            <url>file:///usr/local/virtru-maven/</url>
        +            <url>file:///home/tucker/git/virtru/smtp-proxy/virtru-maven/</url>
                 </repository>
             </repositories>
1. From within the repo clone, run `mvn` using the sonatype clm plugin

        mvn package com.sonatype.clm:clm-maven-plugin:evaluate \
            -Dclm.serverUrl=http://localhost:8070 \
            -Dclm.username=admin \
            -Dclm.password=admin123 \
            -Dclm.applicationId=[application]
1. View the report at the link provided at the end of the run

**NOTE:** Change [application] to the Application Id you entered in the server configuration section.

## Notes and Links

* https://books.sonatype.com/sonatype-clm-book/html/book/index.html
* http://books.sonatype.com/sonatype-clm-book/html/book/clm-server-evaluation.html
