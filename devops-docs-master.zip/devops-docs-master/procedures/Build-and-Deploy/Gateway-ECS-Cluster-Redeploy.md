# Gateway ECS Cluster Redeploy

## Summary

This document describges the process for redeploying the EC2 host instances that are part of the Gateway ECS cluster (in our dogfooding environment) on AWS.

## Prerequisites

* AWS CLI
* AWS production account key and secret for API access

## Warning

Currently the Gateway ECS hosts store everything locally on disk. When we redeploy we build a new AMI and deploy that AMI, effectively terminating the previous instances. If there were any "stuck" emails in postfix on the old instances, they would be lost. There is planned work to solve this using EFS or some sort of persistent EBS volumes, but as of now, this is not in place. Also, only redeploy production01 off-hours to avoid any lost e-mail due this.

## Build an AMI for develop01, develop02, develop03

**IMPORTANT**:
- For develop01 and staging01, set: INSTANCE_TYPE=m3.medium. For production01, set: INSTANCE_TYPE=c4.2xlarge

Set:
- `ENVIRONMENT_NAME=develop01 #staging01 or production01`
- `ANSIBLE_VAULT_PASSWORD_PATH=~/.ansible_vault_password`

### Get the base AMI:

```bash
BASE_AMI_ID=$(aws dynamodb query \
  --table-name BakedAmi \
  --region us-east-1 \
  --key-condition-expression "AmiNameOsType = :amiNameOsType" \
  --expression-attribute-values '{":amiNameOsType":{"S":"base_cis#ubuntu-trusty-cis"}}' \
  --no-scan-index-forward \
  --limit 1 | jq -r '.Items[0].AmiId.S')
```

### Create the AMI:

```bash
ansible-playbook -i hosts/hosts.ini --tags=launch_instance,create_ecs_ami -u ubuntu --private-key ~/.ssh/ami-key-pair-2017-10-16.pem --vault-password-file=$ANSIBLE_VAULT_PASSWORD_PATH --extra-vars '{"region":"us-east-1","ami_name":"ecs","instance_type":"'$INSTANCE_TYPE'","version":"manual-run-'$USER'-'$(date -u +%Y-%m-%dT%H-%M-%SZ)'","environment_name":"develop01","base_ami_id":"'$BASE_AMI_ID'"}' playbooks/ami.yml
```
Save the AMI ID from the output above, e.g.

> ok: [10.1.60.92 -> localhost] => {
>     "msg": "AMI ID = ami-e2ee9598"
> }

As: `AMI_ID=ami-e2ee9598`

### Deploy the AMI:

```bash
ansible-playbook -i hosts/hosts.ini --tags=deploy_new_ami -u ubuntu --private-key ~/.ssh/ami-key-pair-2017-10-16.pem --vault-password-file=$ANSIBLE_VAULT_PASSWORD_PATH --extra-vars '{"region":"us-east-1","ami_name":"gateway","instance_type":"'$INSTANCE_TYPE'","version": "manual-run-'$USER'-'$(date -u +%Y-%m-%dT%H-%M-%SZ)'","environment_name":"'$ENVIRONMENT_NAME'","instance_profile_name":"gateway_iam_instance_profile_'$ENVIRONMENT_NAME'","ami_id": "'$AMI_ID'"}' playbooks/ami.yml
```

### Launch an updated service or task:

*(If something in the container changes, or to redeploy a new container version, this can be used)*

Set:
- `DOCKER_TAG=2.1.33 # example - choose the latest version`

```bash
ansible-playbook -i hosts/hosts.ini --tags=launch_ecs_service_and_task --extra-vars '{"docker_repo":"gateway", "ami_name":"gateway","environment_name":"'$ENVIRONMENT_NAME'","docker_tag":"'$DOCKER_TAG'","executing_user": "'$USER'"}' playbooks/ami.yml --vault-password-file=$ANSIBLE_VAULT_PASSWORD_PATH
```

## Notes

### Gateway Team

Karthik, Cody, and Mohame have been granted login and docker group access to these hosts via
[CAB-276](https://virtru.atlassian.net/browse/CAB-276), [CAB-277](https://virtru.atlassian.net/browse/CAB-277), and [CAB-307](https://virtru.atlassian.net/browse/CAB-307).  As we don't currently
have a way to grant granular access to people, this was done manually as a
one-off.  In these event that these hosts are redeployed, this access will
need to be re-established.  The following ansible snippet can be used (in
conjunction with his pubkey and a hosts file with all the gateway container
hosts) to re-establish their access:

```
---
- hosts: all
  tasks:
    - name: Create custom groups
      become: yes
      group:
        name: "{{ item }}"
      with_items:
        - ccoggins
        - karthik
        - mohamed

    - name: Create custom users
      become: yes
      user:
        name: "{{ item }}"
        group: "{{ item }}"
        groups: docker,sshallowed
        shell: /bin/bash
      with_items:
        - ccoggins
        - karthik
        - mohamed

    - name: Write pubkey for users
      become: yes
      authorized_key:
        user: "{{ item | replace('.pub', '') }}"
        state: present
        key: "{{ lookup('file', item) }}"
      with_items:
        - ccoggins.pub
        - karthik.pub
        - mohamed.pub
```

This is the command used to apply this change: `ansible-playbook -vvvv -i hosts/gateway_team.ini playbooks/gateway_team.yml -u cbean --private-key ${KEY_FILE} -K --vault-password-file ${VAULT_FILE}`

Make sure the .pub files are in the same directory as the playbook and the contents of `hosts/gateway_team.ini` might look like:

```
[all]
ip1
ip2
ip3
```
