# Replacing an Inbound Proxy Instance

## Summary

This document describes the process for replacing an "inbound proxy" instance.

## Prerequisites

* Access to the AWS environment where the instance has failed
* Access to the buildkite pipeline used to deploy a replacement instance

## Procedure

This procedure should be followed when there's a need to replace an inbound proxy instance.  This could be because due to a
new needing to be deploted or a failed instance.

This procedure is broken up into three parts:
1. Launching a replacement instance
1. Swapping the EIP
1. Stopping the existing instance

### Deploy a New Instance

1. Navigate to the [inbound-proxy-services](https://buildkite.com/virtru/inbound-proxy-services) pipeline in Buildkite
1. Click the "New Build" button and provide a meaningful title
1. Click "Create Build" and follow the prompts

**NOTE:** This section is light.  Need to do a deploy and update with more detail.

### Swapping the EIP to the New Instance

1. Login to the AWS console using the account specific link
1. Navigate to "EC2" from the "Services" menu at the top
1. Click on the "Instances" link on the left hand side
1. Select the instance currently using the target EIP
1. From the information pane, click on the IP address to the right of "IPv4 Public IP" in the "Description" tab
1. From the "Elastic IP" screen, with the EIP in question selected, click on the "Actions" button and select "Associate address"
1. From the "Associate address" screen, select the new target instance in the "Instance" menu and click the "Associate" button

### Stopping the Existing Inbound Proxy Instance

1. Login to the AWS console using the account specific link
1. Navigate to "EC2" from the "Services" menu at the top
1. Click on the "Instances" link on the left hand side
1. Select the instance to replace from the list in the frame on the right
1. Click on the "Actions" button near the top and navigate to "Instance State" and select "Stop"
