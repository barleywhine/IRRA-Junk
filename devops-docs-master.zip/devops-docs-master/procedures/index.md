# DevOps Procedures

This repository contains all of the "devops" procedural documentaion to support
the Virtru infrastructure.

## Using these docs

The docs in this repo are written in Markdown.  They can be read in a rendered
form through the GitHub web UI or any other software that will render
Markdown.  Alternatively, you can serve them locally on by using the mkdocs
Python package.  Once installed, simply clone this repo and run
`mkdocs serve` for the root level and visit http://localhost:8000.  (This is
the default.  Visit the appropriate location/port if you change it yourself.)

## Adding new documentation

Any docs you add to the procedures/ directory in this repo will be automatically
linked via mkdocs when serving.  To render links correctly, name the file the
same as the title, capitalize the filename as you would the title and use
hyphens for spaces.

Example: Romeo and Juliet => Romeo-and-Juliet.md
