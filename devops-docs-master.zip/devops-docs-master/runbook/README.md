# DevOps / On-Call Runbook

## Table of Contents

#### General Troubleshooting
- [Checking Logs](#checking-logs)
- [Checking Elasticsearch Index Backup Service](#elasticsearch-index-backup-service)
- [DNS](#dns)
- [Datadog Monitoring Service](#datadog-monitoring-service)
- [New Relic Application Monitoring](#new-relic-monitoring)
- [Elasticsearch Useful Commands](#elasticsearch-useful-commands)
- [Shudder](#shudder)
- [Domain Refresh Purge Queue in SQS](#domain-refresh-purge-queue-in-sqs)
- [Monitor Cloudant Indexing Activity](#monitor-cloudant-indexing-activity)
- [Using AWS Role Assumption from the CLI (MARS)](#using-aws-role-assumption-from-the-cli-mars)
- [Switching Roles in the AWS Console (MARS)](#switching-roles-in-the-aws-console-mars)

#### Responding to Incidents

- [Service Degraded (Apdex)](#service-degraded)
    - [Quick checks, what to look for](#service-degraded-alarm)
- [Production SSH Alert](#ssh-session-to-production-instance)
- [Filebeat backpressure](#filebeat-backpressure)
- [DynamoDB throttles / Underprovisioning Alarms](#dynamodb-throttles)
- [Canary Failures](#canaries)

#### Scenarios and Solutions

- [Build and Deploy (Bamboo/Buildkite or manually)](#build-deploy)
    - [Buildkite](#build-deploy-buildkite)
    - [Bamboo](#build-deploy-bamboo)
    - [Manually](#build-deploy-manually)
- [Emergency Rollbacks](#emergency-rollbacks)
    - [Blue/green Rollbacks](#emergency-rollbacks-blue-green)
    - [Rolling Rollbacks](#emergency-rollbacks-rolling)
- [Audit Worker CPU Spikes on Domain Syncs](#audit-worker-cpu-spikes)
- [Audit Worker Dead Letter Queue Filling Up](#audit-worker-dead-letter-fill-up)
- [Logstash CPU Spikes](#logstash-cpu-spikes)
- [Logstash Memory Spikes](#logstash-memory-spikes)
- [Third Party DNS Outage](#third-party-dns-outage)
- [Marketing Site Outage](#marketing-site-outage)
- [Secure Reader /start/ 404](#sr-start-404)
- [Logging Stack - Endpoint unavailability scenarios](#logging-endpoint-down)
- [Logging Stack - Upgrading](#logging-upgrade)
- [Logging Stack - Launching New Stack](#logging-launch)
- [Manually redeploy buildkite build agents](#manually-redeploying-buildkite-build-agents)
- [Instance won't shut down](#shudder-resume)
- [Auto Scaling is Broken](#shudder-resume)
- [Fix stalled Elasticsearch Snapshots](#fix-stalled-elasticsearch-snapshots)
- [Domain Worker Maximum Message Age](#domain-worker-maximum-message-age)
- [Block an IP Address](#block-an-ip-address)
- [Add users to the office VPN (fortigate)](#fortigate-vpn)
- [Setup iOS Buildkite Agent](#ios-agent-setup)


## Intro

Having a relevant "runbook" for Ops incidents can greatly improve our Mean Time to Recovery (MTTR) in the event of an outage or service impacting incident.

As this document grows, items might be grouped differently into sections and then possibly split out into sub-directories.

##### Here's a prescribed set of general steps to take which can apply in most situations:

1. Determine and confirm the problem
2. Post to #ops in Slack that you are handling the issue along with any other updates (this will be used to construct the timeline in the post-mortem)
3. Determine and apply the first action that should be taken to remediate the problem
4. After the problem is resolved, a post-mortem should be created in the form of a JIRA issue created as type "Ops Incident" under the [Web Stack (WS) Project](https://virtru.atlassian.net/projects/WS).

Also, make sure to refer to the [On-Call Handbook](https://docs.google.com/document/d/1wkmBFmyhDOw75BTGdUkSkkInpWo6nQtMvoVJouvj3LM/).

## General Troubleshooting

#### <a name="checking-logs">Checking Logs</a>

All of the logs are handled via the ELK Stack (Elasticsearch, Logstash, and Kibana). Oftentimes an alert will come from Datadog concerning an increase in 500 errors from Node.js. To get additional context on this, we can log into Kibana.

> Note about browser compatibility: As of the Kibana web app version 4.5.0 (according to their global JS variable `__KBN__`), the search field does not always function properly in Chrome but seems to work fine in Firefox and Safari.

1. Login to Kibana, for example use https://logs-prodlogs-common01.virtru.internal for our production environment. The credentials are in the shared 1Password Ops Vault. If that URL does not resolve, try going to the AWS console -> EC2 -> Load Balancers and use the DNS name for the `kibana-prodlogs-c01-int` ELB.
2. By default, the timeframe of the `Discover` tab will be set in the upper right corner. Click that area to change the time frame. Once set, the histogram (chart) and data will be updated to reflect the correct time range. Using your mouse, you can select an area of the histogram to drill down further.
3. Once the time range has been defined, a search can be done in the top search bar. You can take a field like `err.code` and combine it with a value like `500` via a colon like: `err.code:500` to search for documents that had a 500 error. Other general search terms can be used along with a field search to further refine the results.

![Discover-Start-Annotated](.screenshots/Kibana-Discover-Start-Annotated.jpg)

To see if logs are actively flowing into Elasticsearch:

1. Login to Kibana, for example use https://logs-prodlogs-common01.virtru.internal for our production environment. The credentials are in the shared 1Password Ops Vault. If that URL does not resolve, try going to the AWS console -> EC2 -> Load Balancers and use the DNS name for the `kibana-prodlogs-c01-int` ELB.
2. Look at the time of the most recent log entry, it should be within 30 seconds of the current time.
3. Note the shape of the histogram, does it exibit [signs of backpressure](#filebeat-backpressure), or is there a sharp drop off?

----

#### <a name="dns">DNS</a>

Our instances use `dnsmasq` for DNS caching to improve DNS response times.

To see if DNS is being pulled from cache, or requested from upstream you have to take several steps:

1. Modify the dnsmasq config, /etc/dnsmasq.conf, to have the following line: log-queries
2. Restart dnsmasq: `sudo service dnsmasq restart`
3. Tail the log file: `sudo tail -f /var/log/syslog`
4. Execute a request for the domain in question: `dig somedomain.com`

----

#### <a name="datadog-monitoring-service">Datadog Monitoring Service</a>

We send values to [Datadog](https://app.datadoghq.com/account/login?next=%2Fevent%2Fstream) across a wide variety of `metrics`. These are sent as either Alerts or Warnings via PagerDuty and Slack from `monitors`. Basic instructions with what actions to take on a particular alert should be included inside of the alert. Datadog also has integration with vendors we use such as AWS which it can use to automatically monitor those services.

##### Muting an Alarm

Never disable an alarm. If an incident is being worked on and alarms keep firing, it might be helpful to temporarily mute it. In Slack, for example, an alarm may be posted to #ops. If you click on the title link, it will bring up the monitor page in Datadog. From here, under the status tab towards the upper right of the page, there's a little volume icon which is the mute button to the left of the gear (settings) icon. Click this and choose to silence the alarm for a time frame.

##### Muting a Host

If a particular instance is temporary and alarms can be ignored for it, it can be muted by navigating to the [Infrastructure Map](https://app.datadoghq.com/infrastructure/map) page in Datadog, filtering by a host's attribute, clicking on the green hexagon that represents the host, and then clicking the "mute host" button in the upper right of the modal that appears.

----

#### <a name="new-relic-monitoring">New Relic Application Monitoring</a>

[New Relic](https://rpm.newrelic.com/) can monitor at an application level so it can be troubleshooted via stack traces, errors, and latency issues. New Relic can be very useful to monitor external services that are used in our application, including any related errors and latency to those services.

----

#### <a name="elasticsearch-useful-commands">Elasticsearch Useful Commands</a>

**Tags**: *elastic search, elasticsearch, curator*

Here's a few useful commands that can give you information about the elasticsearch cluster status on the command line. These are known to work when run on a master node pointing at localhost.

The following commands can also be put into Kibana (Dev Tools, Console) in the following format:

```
GET /_cluster/stats
```

or

```
GET /_cluster/allocation/explain
{
  "index": "logstash-2017.06.03",
  "shard": 0,
  "primary": false
}
```

**<u>Cluster Information</u>**

**General Cluster Information:**

``curl -XGET -k -u admin:passwordXXX "https://127.0.0.1:9200/_cluster/stats?human&pretty"``
Returns overall cluster status.

**Health:**

``curl -XGET -k -u admin:passwordXXX "https://127.0.0.1:9200/_cluster/health?v&ts=false&h=cluster,status,nt,nd,shards,pri,relo,init,unassign,pending_task,mtwt,asp"``
Return a summary of cluster health, green, yellow (primary shards good, replicas need allocation), red (primary shards not available, possible data loss).

**Node listing:**

``curl -XGET -k -u admin:passwordXXX "https://127.0.0.1:9200/_cat/nodes?h=cpu,l,r,m,ip,hp,disk,name,iic,iif,mc,sc&s=name:desc&pretty=true&v"``
Detailed information about each node in the cluster.

**Full Cluster Settings and Stats:**

``curl -XGET -k -u admin:passwordXXX "https://127.0.0.1:9200/_nodes/stats?pretty"``
Long listing of all the information from every instance (node) in the cluster.

<u>**Indexes & Shards**</u>

**Indecies:**

``curl -XGET -k -u admin:passwordXXX "https://127.0.0.1:9200/_cat/indices?pretty"``
Lists all the indecies.

**Health of each index:**

``curl -XGET -k -u admin:passwordXXX "https://127.0.0.1:9200/_cluster/health?level=indices&pretty"``
Lists all the shards, their status, locations, and if they are primaries or replicas

**Shards:**

``curl -XGET -k -u admin:passwordXXX "https://127.0.0.1:9200/_cat/shards?v&h=index,shard,pr,state,store,node,unassigned.reason&s=index"``
Lists all the shards, their status, locations, and if they are primaries or replicas

**Index Settings:**

``curl -XGET -k -u admin:passwordXXX "https://127.0.0.1:9200/logstash-2017.03.08/_settings?pretty"``
This format gets you more information about a specific index and its settings

**Unassigned Shards:**

``curl -XGET -k -u admin:passwordXXX "https://127.0.0.1:9200/_cat/shards?h=index,shard,prirep,state,unassigned.reason"| grep UNASSIGNED``
Shows all unassigned shards and reason for unassignment.

<u>**Cluster Activity**</u>

**Shards allocation status:**

```
GET /_cluster/allocation/explain
{
  "index": "logstash-2017.06.03",
  "shard": 0,
  "primary": false
}
```

Shows the allocation status of a specific shard and reason for allocation.

**Pending tasks:**

``curl -XGET -k -u admin:passwordXXX "https://127.0.0.1:9200/_cluster/pending_tasks?pretty"``
Lists any pending tasks for the cluster

**Hot Threads:**

``curl -XGET -k -u admin:passwordXXX "https://127.0.0.1:9200/_nodes/hot_threads?pretty"``
Shows what is taking up CPU on the cluster

**<u>Maintenance</u>**

Every time a node goes down and/or and new node comes up, the cluster redistributes the shards, which may not be desired. If you need to restart the elasticsearch service on a node (for example, to update settings), you should first disable shard allocation, and turn it back on when done.

```
curl -XPUT -k -u admin:passwordXXX "https://127.0.0.1:9200/_cluster/settings" -d '{ "transient" : { "cluster.routing.allocation.enable" : "none" } }'
```

``sudo service elasticsearch restart``

```
curl -XPUT -k -u admin:passwordXXX "https://127.0.0.1:9200/_cluster/settings" -d '{ "transient" : { "cluster.routing.allocation.enable" : "all" } }'
```

Sometimes it is necessary to manually reroute / allocate shards if the cluster is yellow and not automatically recovering. The following command allocates a specific replica shard of a specific index to a specific hot node. See the Elasticsearch documentation for [additional reroute commands](https://www.elastic.co/guide/en/elasticsearch/reference/current/cluster-reroute.html).

```
curl -XPOST -k -u admin:passwordXXX "https://127.0.0.1:9200/_cluster/reroute?pretty" -d '{ "commands" : [ { "allocate_replica" : { "index" : "logstash-2017.04.07", "shard" : 7, "node" : "elasticsearch_hot_common-ip-10-5-79-180" } } ] }'
```

#### <a name="shudder">Shudder</a>

Shudder is a script that runs on instances that plays a role in safely shutting down instances that are spawned by an auto scale group.

The process goes like this:

1. An auto scale group receives a scale in event. This can happen from a deployment, someone reducing the amount of servers we want to run, or the deletion of an auto scale group.
2. The auto scale group sends a notification into Amazon's SNS service.
3. Amazon SNS sends a message to Amazon's SQS service.
4. The shudder daemon monitors the SQS service. When it sees an event is runs through commands it's configured to execute.

FAQ:

Q: Is shudder an original tool by virtru?
A: No, it was originally written by a company called scopely, virtru has extended its functionality

Q: What language is shudder written in?
A: Python

Q: What does shudder do when it launches?
A: Shudder creates a single SQS queue per instance, and subscribes it to the appropriate SNS topic.

Q: How many SNS topics are there?
A: There is one SNS topic per application per environment.

Q: How do you prevent shudder from subscribing to other SNS topics?
A: Strict Amazon IAM roles are used to prevent this.

Q: How do you prevent shudder from reading other SQS queues?
A: Strict Amazon IAM roles are used to prevent this.

Q: What does shudder do when it gets a message?
A: The first step it takes is to decide if the SQS message applies to itself. Then it unsubscribe the SQS queue from SNS. It then deletes the SQS queue. Then it executes a list of commands in its configuration file. These commands are run in the background. Every thirty seconds it sends a heartbeat to the autoscale group to let it know it's still working. When it is finished running through all the commands it notifies the auto scale group it may continue on with the termination.

Q: Does shudder clean up its queue?
A: Yes, before shutting down it deletes its queue

Q: How do you prevent shudder from deleting other SQS queues?
A: Strict Amazon IAM roles are used to prevent this.

Q: How can I see the lifecycle hooks?
A: Run the following command, substituting the auto scale group name in. `aws autoscaling describe-lifecycle-hooks --auto-scaling-group-name <auto scale group name>`

Q: How can I see the SNS topics?
A: Run the following command: `aws list-topics | grep shudder`

Q: How can I see the SQS queues?
A: Run the following command: `aws list-queues | grep shudder`

----

## Responding to Incidents

#### <a name="service-degraded">Service Degraded (Apdex)</a>

The following instructions can be followed to debug any number of possible issues and to check the current status of Virtru's services.

**Apdex definition:**

Apdex is an industry standard to measure users' satisfaction with the response time of web applications and services. Each request to our applications are compared against a response time threshold (T) that we have defined (400ms for acm, 800ms for accounts).

* Satisfied: less than or equal to T
* Tolerating: greater than T and less than or equal to 4T
* Frustrated: greater than 4T. Any request that raises a server-side error is considered a frustrating response, no matter how fast it returns to the user.

![apdex](.screenshots/Apdex.gif)

TLDR: Apdex of 1, everyone is satisfied. Apdex of 0, everyone is frustrated. A score <0.65 generated an alarm.

**<a name="service-degraded-alarm">Quick checks, what to look out for:</a>**

> [Acm Apdex](https://rpm.newrelic.com/accounts/1215555/applications/25690375)
>
> [Accounts Apdex](https://rpm.newrelic.com/accounts/1215555/applications/25706196)

Look for spikes in transaction times, throughput, or error rates. For transaction time, the blue line is our application response, green represents external services. If green spikes and blue does not, likely an issue with an external service (check [external services](https://rpm.newrelic.com/accounts/1215555/applications/25690375/externals) on left).

----
> [Acm Errors](https://rpm.newrelic.com/accounts/1215555/applications/25690375/filterable_errors)
>
> [Accounts Errors](https://rpm.newrelic.com/accounts/1215555/applications/25706196/filterable_errors)

Our applications (and users) generate a steady stream of errors. Error rates as a percentage of transactions are lowest during peak traffic, and rise overnight.

The errors worthy of further investigation are generally `InternalServerError` and `UnexpectedResponseError`
----
> [Accounts Transactions](https://rpm.newrelic.com/accounts/1215555/applications/25706196/transactions)
>
> [Acm Transactions](https://rpm.newrelic.com/accounts/1215555/applications/25690375/transactions)
>
> [Audit Worker Transactions](https://rpm.newrelic.com/accounts/1215555/applications/35329166/transactions)
>
> [Domain Worker Transactions](https://rpm.newrelic.com/accounts/1215555/applications/35335732/transactions)

Look accross all applications to see what our applications were doing over time. Note spikes in types of transactions for further investigation.
----
**Further investigation:**

[Squid outbound connection errors](https://logs-prodlogs-common01.virtru.internal/app/kibana#/discover/caa9cfc0-68c2-11e7-b461-855941f0da76) - Useful for diagnosing dropped connections to third parties (e.g., Cloudant) and InternalServerError/UnexpectedResponseError reported by New Relic.

[Outbound Requests to Cloudant (count by service) - Bar graph](https://logs-prodlogs-common01.virtru.internal/app/kibana#/dashboard/13614930-5781-11e7-8ed9-e9f92c05784f)

[500 application errors](https://logs-prodlogs-common01.virtru.internal/app/kibana#/discover/53107220-34d3-11e7-84e3-c707e8332a6f)

[All application errors](https://logs-prodlogs-common01.virtru.internal/app/kibana#/discover/Errors-Any)

[Application InternalServerErrors](https://logs-prodlogs-common01.virtru.internal/app/kibana#/discover/8aee41a0-68bc-11e7-b461-855941f0da76)

[Application UnexpectedResponseErrors](https://logs-prodlogs-common01.virtru.internal/app/kibana#/discover/d6a106d0-6dcd-11e7-b0b4-2b2a6f4bf905)

[Domain Worker processing](https://logs-prodlogs-common01.virtru.internal/app/kibana#/discover/19c2cdb0-4540-11e7-83eb-3d0d485467a1)

#### <a name="ssh-session-to-production-instance">Production SSH Alert</a>

SSH'ing into a production system creates a security risk and the instance(s) involved should be considered tainted.

View the New Relic Insights [Security Dashboard](https://insights.newrelic.com/accounts/1215555/dashboards/347897) for a list of the most recent production SSH sessions. Instances should be immediately terminated if suspicious activity is noted, and in the case of SSH for debugging purposes, the instance(s) should be terminated upon completion of debugging activity.

#### <a name="filebeat-backpressure">Filebeat Backpressure</a>

If logstash, s3, or elasticsearch are down or slow, they will apply backpressure on filebeat, and logs will buffer on the application instances. Each application instance can store ~6gb+ of logs, which should hold many days worth of logs if necessary.

If you recieve a backpressure alarm, you should determine if anything is down, or just slow. Logging into Kibana and looking at [the Discover histogram](https://logs-prodlogs-common01.virtru.internal/app/kibana#/discover) you can quickly determine what might be happening.

![filebeatbackpressure](.screenshots/log-backpressure.png)

If logs were not flowing, we would not see anything on the far right of this histogram. Here we see logs are flowing, but note the unusual shape of the graph. Traffic is increasing from 5-6am (PST) as expected on a weekday, but then the number of logs decrease until present (11am PST). This is not indicative of usual traffic activity, it's a sure sign of the logging cluster being slow and putting backpressure on the application instances. Because Elasticsearch can not always injest all the logs in real time, it is injesting as much as it can, from across the time period in question. Refreshing the graph you would likely see the bars grow across the board from 6:10 to present as Elasticsearch continues to catch up.

The above is an extreme example, and the Elasticsearch cluster has since been tuned for better performance, however it is common during peak traffic to see a slope like the one above in the last ~15 minutes of logs.

If Kibana complains about the connection to elasticsearch, then elasticsearch is likely down and should be diagnosed, see [useful elasticsearch commands](#elasticsearch-useful-commands) section.

If there are no errors in Kibana, but you see no recent logs, it's likely that a [logstash endpoint is down/unavailable](#logging-endpoint-down).

One issue we've been seeing recently is logstash losing it's connection to elasticsearch, likely due to an elasticsearch ELB scaling event where the IPs change and logstash doesn't update.

To diagnose, SSH into [both logstash instances](https://console.aws.amazon.com/ec2/v2/home?region=us-east-1#Instances:search=logstash_prodlogs;sort=desc:tag:Name) and tail the logstash logs `sudo tail -f -n 50 /var/log/logstash/logstash-plain.log` and look for messages like

```
[2017-07-22T03:38:56,854][WARN ][logstash.outputs.elasticsearch] Marking url as dead. Last error: [LogStash::Outputs::ElasticSearch::HttpClient::Pool::HostUnreachableError] Elasticsearch Unreachable: [https://logstash:xxxxxx@elasticsearch-coordinator-prodlogs-common01.virtru.internal:9200/][Manticore::SocketTimeout] Read timed out {:url=>https://logstash:xxxxxx@elasticsearch-coordinator-prodlogs-common01.virtru.internal:9200/, :error_message=>"Elasticsearch Unreachable: [https://logstash:xxxxxx@elasticsearch-coordinator-prodlogs-common01.virtru.internal:9200/][Manticore::SocketTimeout] Read timed out", :error_class=>"LogStash::Outputs::ElasticSearch::HttpClient::Pool::HostUnreachableError"}[2017-07-22T03:38:56,855][ERROR][logstash.outputs.elasticsearch] Attempted to send a bulk request to elasticsearch' but Elasticsearch appears to be unreachable or down! {:error_message=>"Elasticsearch Unreachable: [https://logstash:xxxxxx@elasticsearch-coordinator-prodlogs-common01.virtru.internal:9200/][Manticore::SocketTimeout] Read timed out", :class=>"LogStash::Outputs::ElasticSearch::HttpClient::Pool::HostUnreachableError", :will_retry_in_seconds=>2}~~~~
[2017-07-22T03:38:56,854][WARN ][logstash.outputs.elasticsearch] Marking url as dead. Last error: [LogStash::Outputs::ElasticSearch::HttpClient::Pool::HostUnreachableError] Elasticsearch Unreachable: [https://logstash:xxxxxx@elasticsearch-coordinator-prodlogs-common01.virtru.internal:9200/][Manticore::SocketTimeout] Read timed out {:url=>https://logstash:xxxxxx@elasticsearch-coordinator-prodlogs-common01.virtru.internal:9200/, :error_message=>"Elasticsearch Unreachable: [https://logstash:xxxxxx@elasticsearch-coordinator-prodlogs-common01.virtru.internal:9200/][Manticore::SocketTimeout] Read timed out", :error_class=>"LogStash::Outputs::ElasticSearch::HttpClient::Pool::HostUnreachableError"}
[2017-07-22T03:38:56,855][ERROR][logstash.outputs.elasticsearch] Attempted to send a bulk request to elasticsearch' but Elasticsearch appears to be unreachable or down! {:error_message=>"Elasticsearch Unreachable: [https://logstash:xxxxxx@elasticsearch-coordinator-prodlogs-common01.virtru.internal:9200/][Manticore::SocketTimeout] Read timed out", :class=>"LogStash::Outputs::ElasticSearch::HttpClient::Pool::HostUnreachableError", :will_retry_in_seconds=>2}
```

To fix, restart logstash `sudo service logstash restart`

If the problem persists, additional information can be found in JIRA under [SRE-704](https://virtru.atlassian.net/browse/SRE-704).

#### <a name="dynamodb-throttles">Respond to DynamoDB ReadThrottleEvents/WriteThrottleEvents/Underprovisioning alerts</a>

When you get this alarm, it means there is customer impact due to a DynamoDB table or index being underprovisioned. Customers making API requests that need that table or index will be experiencing failures.

The steps below will have you mitigating immediate customer impact, by manually increasing provisioned capacity.

To remediate:

1. Visit the AWS DynamoDB console in the environment that is in alarm (e.g. MARS Production): <https://us-east-2.console.aws.amazon.com/dynamodb/home?region=us-east-2#>
1. Left rail --> Tables --> the table named in the alert
1. Metrics tab. Scan the dashboard and find any metrics that are breaching the threshold shown with a red line. This should match the table or index named in the alarm you're getting, but scan for others that are in alarm as well. For each, note what the capacity would have needed to be.
1. Capacity tab. Enter new values for Minimum provisioned capacity. Make them high, 2x of what you think they need to be. Set the Maximum provisioned capacity to 10x of what you set the Minimum provisioned capacity (the console will complain if Max < Min). Ensure the "Apply same settings to global secondary indexes" is checked. Click "Save"
1. Back to Metrics tab. Monitor this dashboard (you will need to manually refresh) and ensure the red line moves up, and the throttle graphs no longer show new data points.
1. YOU'RE NOT DONE. Once out of alarm, and during business hours, make and deploy a change to the MARS terraform to set better min and max autoscaling bounds. Before deploying, ensure that the `read_capacity` and `write_capacity` fields in the respective table and index definitions contain your new MAX values; that will ensure that when you deploy, the capacity will start at your designated max (i.e. overprovisioned).

#### <a name="canaries">Canary Failures</a>

**Tags**: *canary, canaries, database, dynamo, accounts, acm*

The CanaryFail alarm indicates failures by a canary process that regularly makes API requests to our services. A canary that starts reporting failures could indicate a service outage or degradation.

Follow these steps for this alarm:

- Get a quick reading on the state of our systems by looking at the [Accounts](https://rpm.newrelic.com/accounts/1215555/applications/25706196) and [ACM](https://rpm.newrelic.com/accounts/1215555/applications/25690375) New Relic dashboards
- If problems are evident, look for the cause, using the information from the canary failure report (e.g., failures by the app-id-bundles canary would likely indicate authentication problems affecting Accounts)
- If problems are not evident, it's possible (but not necessarily the case) that the alarm was triggered by a problem with the [canary process](https://github.com/virtru/virtru-canaries-backend)
    - Check the [logs](https://us-east-2.console.aws.amazon.com/cloudwatch/home?region=us-east-2#dashboards:) and [dashboards](https://us-east-2.console.aws.amazon.com/cloudwatch/home?region=us-east-2#dashboards:) in the `virtru-canary` AWS account

Canary details:

- In production, the canaries hit our APIs once every minute. The requests trigger database accesses, replicating the flow of a user's client making API requests
- The time a canary run takes, which is shown in the canary dashboards, is only meaningful when compared with the canary's own historical data for that metric, because the time reflects the overall canary run, and the different canaries make varying amounts of requests

------

## Scenarios and Solutions

#### <a name="build-deploy">Build and Deploy (Bamboo/Buildkite)</a>

##### <a name="build-deploy-buildkite">Buildkite:</a>

The build/deploy pipelines for each service are run automatically when a new release is pushed to github on a feature/ branch (deploys to a developXX environment) or master branch (deploys to staging01 and then following manual unblock, production01).

Pipelines can be also be manually run or re-run to deploy something specific, but the build and deploy processes are tied together in the pipelines, so both steps will need to complete for each run.

![build-deploy-buildkite-new-build](.screenshots/build-deploy-buildkite-new-build.png)

Manually run a new build: In the desired application pipeline, click `New Build` and specify the branch and desired commit.

![build-deploy-buildkite-rebuild](.screenshots/build-deploy-buildkite-rebuild.png)

Re-deploy a previous build: In the desired application pipeline, select the desired build on the desired branch and click `Rebuild`.

##### <a name="build-deploy-bamboo">Bamboo:</a>

Bamboo functions similarly, though the build and deploy processes are separated slightly.

![build-deploy-buildkite-rebuild](.screenshots/build-deploy-bamboo-new-build.png)

If you would like to manually deploy a new build, you should first manually run the build. Be sure to select the desired environment where you will be deploying the build.

![build-deploy-buildkite-rebuild](.screenshots/build-deploy-bamboo-deploy.png)

To deploy an existing build, select the desired application and environment under Deployments, and then the desired Release. You can also create a new release based on an existing build. When the desired release is selected, you can deploy it to the desired environment.

##### <a name="build-deploy-manually">Manual Build/Deploy (for blue/green service):</a>

Following commands show an example events develop02 build and deploy.

Build AMI:

```
ansible-playbook -vv -i hosts/hosts.ini --tags=launch_instance,create_events_ami -u ubuntu --private-key ~/.ssh/ami-key-pair-2016-12-18.pem --ask-vault-pass --extra-vars '{"region":"us-east-1","ami_name":"events","instance_profile_name":"events_iam_instance_profile_develop02","instance_type":"m3.medium","version":"manual-run-'$USER'-'(date -u +%Y-%m-%dT%H-%M-%SZ)'","environment_name":"develop02","base_ami_id":"LATEST_BASE_CIS_VIRTRU_WEB_BASE_AMI_ID","use_node_6":"false"}' playbooks/ami_bakery.yml
```

Prep Blue/green ASGs (to cleanup previous failures, should result in no changes):

```
ansible-playbook -vv -i hosts/hosts.ini --ask-vault-pass --extra-vars '{"environment_name":"develop02","region":"us-east-1","ami_name":"events"}' playbooks/ami_deployer.yml --tags "deploy_ami_blue_green_prep"
```

Attach inactive ASG to ELB:

```
python devops-blue-green-asg-update-script.py --application=events --environment=develop02 --action=attach
```

Deploy - create launch config, assign it to inactive ASG, launch instances:

```
ansible-playbook -vv -i hosts/hosts.ini --ask-vault-pass --tags "deploy_ami_blue_green" --extra-vars '{"environment_name":"develop02","region":"us-east-1","ami_name":"events","instance_profile_name":"events_iam_instance_profile_develop02","instance_type":"m3.medium","version":"manual-run-'$USER'-'(date -u +%Y-%m-%dT%H-%M-%SZ)'","ami_id":"BUILD_ID_OUTPUT_FROM_BUILD_STEP"}' playbooks/ami_deployer.yml
```

Detatch inactive ASG to ELB (run this on both successful/failed deploy, to cleanup):

```
python devops-blue-green-asg-update-script.py --application=events --environment=develop02 --action=detach
```

Cleanup Blue/Green ASGs (run this on both successful/failed deploy, to cleanup):

```
ansible-playbook -vv -i hosts/hosts.ini --ask-vault-pass --extra-vars '{"environment_name":"develop02","region":"us-east-1","ami_name":"events"}' playbooks/ami_deployer.yml --tags "deploy_ami_blue_green_prep"
```

#### <a name="emergency-rollbacks">Emergency Rollbacks</a>

Generally, deploying a service should happen in Bamboo / Buildkite where tests can be run during builds and deployments will happen in staging01 before being deployed to production01.

However, if a newly deployed service version is not working, and a previous version is known to work, it may be faster to conduct a manual rollback in AWS.

All Virtru services are deployed within Auto Scaling Groups (ASGs). Select services are deployed using _blue/_green ASGs, which make deploys & rollbacks significantly faster.

Services currently using blue/green deployments (02/03/2017):

* Accounts
* ACM
* Admin Panel
* Events

Services planned for blue/green deployments, but currently using rolling deployments (02/03/2017):

* Secure/www
* Squid Proxy

Services using rolling deployments:

* Audit Worker
* Dashboard
* Domain Worker
* Elasticsearch/Kibana/Redis (special deployment instructions needed here)
* Secure Reader

##### <a name="emergency-rollbacks-blue-green">Blue/green rollbacks:</a>

**Blue/green rollback TLDR:** Attach inactive ASG to the ELB, launch instances in the inactive ASG with the desired LC and number of instances. Detach the other ASG from the ELB, terminate those instances, and update tags on both _blue/_green ASGs to denote the new active ASG.

Further details below:

![rollback-blue-green-acm-1](.screenshots/rollback-blue-green-acm-1.png)
Above, we see our ACM service in production01. This is found in the EC2 Dashboard, Auto Scaling Groups, and filtering based on &lt;service name&gt;\_asg\_&lt;environment&gt;. Note that there are three ASGs. In this case, acm_asg_production01 is unused (and should be deleted soon) as we have moved over to use the _blue and _green ASGs. Here, the _green ASG has 40 instances and has been assigned to the Load Balancer (ELB) `acm-p01`, actively serving traffic.

![rollback-blue-green-acm-2-tags](.screenshots/rollback-blue-green-acm-2-tags.png)
Note the tags as well. The _green ASG has been tagged with active=True, denoting that it is the active ASG. The _blue ASG in this example has been tagged active=False.

During a deploy, our Ansible scripts would deploy a new version to the inactive ASG (_blue in this case), attach the inactive to the Load Balancer, and when healthy, detach _green, and then update the `active` tags on both ASGs, denoting _blue as the new active ASG.

We can do this process manually if we would like to quickly revert to an old version of the application.

![rollback-blue-green-acm-3-inactive](.screenshots/rollback-blue-green-acm-3-inactive.png)
Let’s say the active deploy has major issues and we want to revert back to an older version. The inactive ASG (_blue in this example) will still be assigned the previous Launch Configuration, but have 0 instances and is not attached to the ELB.

Attach the inactive ASG to the desired Load Balancer (acm-p01), set the number of Desired/Min/Max instances you would like, and click `Save`.

At this point, instances will begin launching on the _blue ASG, and the ELB will test them for health.

The final step will be to detach the _green ASG from the ELB, and update the tags on both the _blue and _green ASGs to denote the correct active ASG. Updating the tags is important so that the next deployment from Bamboo/Buildkite will run as expected. The inactive ASG min/desired instances should also be set to zero to terminate those instances no longer serving traffic.

##### <a name="emergency-rollbacks-rolling">Rolling rollbacks:</a>

**Rolling rollback TLDR:**
* Change the launch config on the ASG (this contains information such as the AMI or image) to the last successful build
* Set the desired quantity on the ASG to 2x the original value (from 4 to 8)
* Confirm that the 4 new instances are healthy (at this point all instances are taking traffic)
* Update the termination policy from "OldestLaunchConfig" to "OldestInstance"
* Set the desired quantity on the ASG back to the original value (from 8 to 4)
* Confirm all is terminated
* Update the termination policy back to "OldestLaunchConfig"

Further details below:
Some services are deployed in a single ASG. Unlike blue/green, where you can spin up instances in a parallel ASG, here we will have to replace instances in the single ASG.

![rollback-rolling-audit-worker-1](.screenshots/rollback-rolling-audit-worker-1.png)
Above is our audit_worker ASG, with 30 instances. To revert back to a previous release, we’ll select the desired Launch Configuration. When selecting a different Launch Configuration, make sure the selected one matches the application name (audit_worker) and environment (production01), as the Launch Configuration dropdown allows you to select other applications and environments.

The Launch Configurations are named to match the Buildkite build uuid (i.e. fdb76ff7-7d21-4b7c-8b7b-9ac4260b23d3), or the bamboo build #. You’ll have to look up the one you want in Buildkite or Bamboo, or search Launch Configurations in AWS, filter by application and environment, and sort by date (link on left just above Auto Scaling Groups).

After selecting the desired Launch Configuration and clicking `Save`, only new instances will launch with the selected Launch Configuration. Update the desired quantity to double the current value, and save the ASG. (You may need to update the max capacity value to accomodate. Take note of the original values for both fields.)

Give it some time for the new new instances to all come online and become healthy. Note, that all instances will be taking traffic at the moment. Update the auto-scaling group termination policy from *OldestLaunchConfig* to *OldestInstance*. Save the ASG.

Now edit the ASG back to its original desired capacity (half of the now current value). Save the ASG. Also, reset the maximum capacity if you had changed it when scaling out. Confirm that the old instances are terminated (you can view the instances tab on the auto-scaling group which will indicate their status).

Finally, edit the ASG and reset the termination policiy back to "OldestLaunchConfig" and save it.

#### <a name="audit-worker-cpu-spikes">Audit Worker CPU Spikes on Domain Syncs</a>

**Tags**: *cpu, audit_worker, domain sync, sqs*

This can occur if a large customer initiates a domain sync process which can overwhelm the Audit Worker service if there are not sufficient Auto Worker instances to process the SQS queue.

**NOTE:** long-term, we should use a scaling policy on the Auto Worker's auto scaling group in AWS to dynamically respond to the queue length. A [JIRA issue](https://virtru.atlassian.net/browse/WS-4703) was created for this.

##### Example JIRA issues:

- [WS-4588](https://virtru.atlassian.net/browse/WS-4588)

##### Monitor names:

- [CPU](https://app.datadoghq.com/monitors#930340)

##### Determination:

Login to the [AWS console for production](https://virtru.signin.aws.amazon.com/console) and navigate to the page for [SQS](https://console.aws.amazon.com/sqs/home?region=us-east-1#). Find the `audit-production01` and click on it. If this queue has a "Messages Available" value of greater than a few thousand, then the queue is backing up and is overwhelming the audit workers.

##### Resolution:

1. Login and visit the page for [EC2 in the AWS Console](https://console.aws.amazon.com/ec2/v2/home?region=us-east-1)
2. Find the [Auto Scaling Groups](https://console.aws.amazon.com/ec2/autoscaling/home?region=us-east-1#AutoScalingGroups:) section (on the left of the page)
3. Click on the audit worker for the environment impacted. For example, on production01 it should be named: audit_worker_asg_production01
4. Click the "edit" button on the Details tab
5. Make note of the current "Desired" value, and update this. If it is currently "10", consider doubling it to "20". If the "Max" value is less than the new "Desired" value, make note of the current "Max" value, and update this to be the same value as the new "Desired" value
6. Click the "Save" button

##### Clean Up:

Once the sync is over, make sure to re-adjust the Auto Scaling Group for the Audit Worker in production01 to what it was prior to scaling up. Create an issue in JIRA in case we need to do it later.

----

#### <a name="audit-worker-dead-letter-fill-up">Audit Worker Dead Letter Queue Filling Up</a>

**Tags**: *sqs, audit_worker, dead letter*

This can occur if a large customer initiates a domain sync process which can overwhelm the Audit Worker service if there not sufficient Auto Worker instances to process the SQS queue.

**NOTE:** long-term, we should use a scaling policy on the Auto Worker's auto scaling group in AWS to dynamically respond to the queue length. This [JIRA issue](https://virtru.atlassian.net/browse/WS-4703) was created for this.

##### Example JIRA issues:

- [WS-4151](https://virtru.atlassian.net/browse/WS-4151)
- [WS-4187](https://virtru.atlassian.net/browse/WS-4187)
- [WS-4283](https://virtru.atlassian.net/browse/WS-4283)
- [WS-4361](https://virtru.atlassian.net/browse/WS-4361)

##### Monitor names:

*N/A*

##### Determination:

PagerDuty might alert with a description such as `Sum ApproximateNumberOfMessagesVisible of 510.0 GreaterThanOrEqualToThreshold 500.0 for QueueName audit-dead-letter-queue-production01`. Login to the [AWS console for production](https://virtru.signin.aws.amazon.com/console) and navigate to the page for [SQS](https://console.aws.amazon.com/sqs/home?region=us-east-1#). Confirm that queue name `audit-dead-letter-queue-production01` has a value for `ApproximateNumberOfMessagesVisible` of over 500.

##### Resolution:

The steps to resolve are [outlined here](https://github.com/virtru/audit-worker/blob/develop/docs/process-dead-letter-queue.md) in the docs subdirectory inside the `audit-worker` repo.

##### Clean Up:

*See instructions in the Resolution step above.*

----

#### <a name="logstash-cpu-spikes">Logstash CPU Spikes</a>

**Tags**: *logstash, elastic search*

Logstash CPU can spike when a large number of logs are being sent to Logstash which then forwards them to Elasticsearch. In the past, this has been seen during domain syncs where audit-worker generates a large portion of the logs.

##### Example JIRA issues:

- [WS-5157](https://virtru.atlassian.net/browse/WS-5157)

##### Monitor names:

- [CPU](https://app.datadoghq.com/monitors#1417525?group=triggered&live=4h)

##### Determination:

1. Look at the graphs in Marvel. Here is the link for [Marvel for production01](https://internal-logs-kibana-p01-int-1120647648.us-east-1.elb.amazonaws.com/app/marvel)
2. Examine the indexing rate, if it has just spiked a lot (2x or more), then there's a good chance that the system is ingesting more logs than usual.

Common reasons for spikes in logs can be:

1. An application is emitting an error at a high frequency
2. A domain sync was kicked off and audit-worker is busy generating logs

For #1, use Kibana and query to look at recent logs that have an error to see if the frequency in the graph has increased. An example query might be: "_exists_:err.name" and then look through the results to further refine.

For #2, check the "Server Resources" section of our [main dashboard for audit-worker](https://app.datadoghq.com/screen/41449/web-service-overview-except-events---new?tpl_var_service=audit_worker) to see if there is a high CPU utilization.

Another way to confirm a domain sync, is in AWS go to SQS. Select the queue name "audit-production01" and click the tab "monitoring". You can see if there is a spike in the number of messages. During a domain sync it is not uncommon to see the "NumberOfMessagesSent" metric jump up to 30,000 or more messages on a 1-hour x-axis.

##### Resolution:

At this time there is nothing that can be done to scale up Elasticsearch quickly enough if this alarm is triggered. Ideally, we would prepare our environment in advance with ample notification due to balancing the cluster and the time it takes.

Elastic (the Elasticsearch parent co.) has suggested to run a hot and warm cluster of Elasticsearch indexes which might be a solution we can explore in the future. In this case the hot instances would host today's indices.

We would just need to monitor that the logs are indexing properly.

1. Logon to the [Kibana dashboard](https://internal-logs-kibana-p01-int-1120647648.us-east-1.elb.amazonaws.com)
2. Go to Marvel by clicking the app selector icon next to "settings" (it has 9 little squares in it). Next click "Marvel". Check the "Indexing rate" on the main page of Marvel.
3. If the rate of ingest is anywhere in the >2000 range the indexing is probably working correctly. Anything less and something is wrong with the log ingest pipeline (Logstash or an agent forwarder or Redis).

##### Clean Up:

N/A

----

#### <a name="logstash-memory-spikes">Logstash Memory Spikes</a>

**Tags**: *logstash, elastic search, elasticsearch, memory*

Logstash memory can spike when a large number of logs are being sent to Logstash which then forwards them to Elasticsearch. In the past, this has been seen as a long line of memory growth that occasionally has small spikes up. Due to what appears to be a memory leak this memory is never released.

##### Example JIRA issues:

- [WS-5488](https://virtru.atlassian.net/browse/WS-5488)

##### Monitor names:

- [Memory Utilization](https://app.datadoghq.com/monitors#889030?group=triggered&live=4h)

##### Determination:

1. Look at the graphs in Marvel. Here is the link for [Marvel for production01](https://internal-logs-kibana-p01-int-1120647648.us-east-1.elb.amazonaws.com/app/marvel)
2. If logs are not being indexed then logstash memory will fill up with logs to ship to elasticsearch
3. There is no way to know currently by looking at logs in kibana to see if they are coming from a specific logstash instance ([ws-5490](https://virtru.atlassian.net/browse/WS-5490))

Common reasons for spikes in logs can be:

1. An application is emitting an error at a high frequency
2. Elasticsearch isn't accepting logs

For #1, use Kibana and query to look at recent logs that have an error to see if the frequency in the graph has increased. An example query might be: "_exists_:err.name" and then look through the results to further refine.

For #2, Look at the graphs in Marvel. Here is the link for [Marvel for production01](https://internal-logs-kibana-p01-int-1120647648.us-east-1.elb.amazonaws.com/app/marvel). If logs are not being indexed then logstash memory will fill up with logs to ship to elasticsearch

##### Resolution:

1. Log into AWS
2. Navigate to [logstash production01 ASG](https://console.aws.amazon.com/ec2/autoscaling/home?region=us-east-1#AutoScalingGroups:id=logs_logstash_asg_production01;view=details;filter=logstash)
3. Find the instance in the "Instances" tab
4. Click "Actions"
5. Click "Set to Standby"
6. When asked if you want to replace it with another instance, answer yes.
7. SSH to the instance causing memory alerts
8. Type ``sudo /etc/init.d/datadog-agent stop``

##### Clean Up:

1. One day after you have performed the resolution steps
2. SSH to the instance causing memory alerts
3. Type ``sudo /etc/init.d/logstash stop``
4. WAIT for logstash to exit cleanly
5. Verify logstash has exited cleanly by running `sudo ps wwwaux | grep logstash`
6. Terminate the instance

----

#### <a name="third-party-dns-outage">Third Party DNS Outage</a>

**Tags**: *dns, cloudant*

This occurs when all or some of our production infrastructure cannot access one or more of the services that we depend on by domain name through DNS.

##### Example JIRA issues:

- [WS-4688](https://virtru.atlassian.net/browse/WS-4688)

##### Monitor names:

- [Outbound DNS Outage](https://app.datadoghq.com/monitors#1251438?group=all&live=1h)
- [Outbound DNS Response Time](https://app.datadoghq.com/monitors#1251437?group=all&live=4h)

##### Determination:

Login to an EC2 instance, replace `example.com` with an affected domain such as `virtru-production.cloudant.com`, and run command:

```bash
dig @169.254.169.253 example.com
```

The IP address `169.254.169.253` is AWS's internal DNS resolver IP. It only works from within their internal network.

If the above times out, or has any empty result in `;; ANSWER SECTION:`, then we can confirm this issue. You can also `ping example.com` to check for a reply.

##### Resolution:

1. Notify the vendor immediately via their support channels. For Cloudant, we would email their support, for example.
2. Determine a valid IP can be obtained for the domain name in question. This might come from the vendor (such as Cloudant) or perhaps trying to get the IP via a `dig @8.8.8.8 example.com`. (Using another nameserver to resolve it). In this example, say we learn that `1.2.3.4` is the `A record` that `example.com` is supposed to point to.
3. Checkout and `cd` to the `ansible/` subdirectory from the [DevOps Deploy repository](https://github.com/virtru/devops-deploy). (Make sure you are on the `develop branch`.)
4. Run the following commands to update all Squid Proxy instances in production01 environment's /etc/hosts file to use the IP directly for a given domain name:

(**WARNING**: replace the IP (1.2.3.4) and domain (example.com) below before running!)

```bash
EC2_INI_PATH=hosts/production01.ec2.ini
ansible tag_server_type_squid_proxy -K -u $USER -i hosts/ec2.py -m shell -a 'echo 1.2.3.4 example.com >> /etc/hosts' -s --ask-vault-pass
```

##### Clean Up:

Make sure to create a follow on task to revert the hosts file changes after the affected service's DNS comes back online. This can be accomplished by terminating the Squid instances in small batches while ensuring that the Auto Scaling Group is launching the correct number of replacements.

----


#### <a name="marketing-site-outage">Marketing Site Outage</a>

**Tags**: *dns*

The <https://www.virtru.com> marketing site is a Wordpress site hosted by WP Engine. Virtru engineering does not control anything for the site other than DNS (via Amazon route53), so if there is a non-DNS problem, contact WP Engine support at <support@wpengine.zendesk.com>.

The site is monitored by a [Pingdom check](https://my.pingdom.com/newchecks/checks) that alerts if the site is not up.

----

#### <a name="sr-start-404">Secure Reader /start/ page 404</a>

**Tags**: *secure reader, wordpress*

If certain SR links that begin with `https://www.virtru.com/start/...` begin to 404, it means that the .htaccess rewrite rules have been reverted to a version without them or removed altogether.

To resolve, checkout the master branch of <https://github.com/virtru-collab/www-wordpress> and create a sftp login in the virtruprod install of <https://my.wpengine.com/installs/virtruprod>. Then in the terminal, navigate to the root of the `www-wordpress` repo and run `sftp -P 2222 {USERNAME}@virtruprod.sftp.wpengine.com`. Run `ls -l .htaccess` and send Christopher Tang the output, then run `put .htaccess` to upload the repo's .htaccess file to the wordpress server. You should be able to test that the rewrite rules work by navigating to <https://www.virtru.com/start/> which will redirect to <https://secure.virtru.com/secure-email/> and redirect back to <https://www.virtru.com/secure-email/>. I believe there is some browser caching issues so if it continues to 404 on one browser, try another or another device. After a few minutes, all browsers and devices should start redirecting again and the pingdom alert will resolve.

The redirect is monitored by a [Pingdom check](https://my.pingdom.com/newchecks/checks#check=2514733) that alerts if the redirect has broken and the /start/ page 404's.

----

####  <a name="logging-endpoint-down">Logging Stack - Filebeat backpressure - /var/log partition disk usage</a>

**Tags**: *filebeat, logstash, elastic search, elasticsearch, s3, logs*

The logging stack involves the following flow: filebeat -> logstash -> s3 & elasticsearch.

If logstash, s3, or elasticsearch are down or slow, they will apply backpressure on filebeat, and logs will buffer on the application instances.

Lets look at an ACM instance.

`sudo ls -lai /var/log/app`

```
95 -rw-r-----  1 root root    11145 Apr  5 17:18 acm.log
32 -rw-r-----  1 root root     4830 Apr  5 16:04 acm.log.1-1491408301.gz
75 -rw-r-----  1 root root     4830 Apr  5 16:00 acm.log.1-1491403194.gz
```

Notice the acm.log file, and the two rotated and compressed logs. We run a helper script every 5 minutes that gzips logs once filebeat has confirmed shippment, and deleted them after a period of time. The above looks as expected.

But what happens if filebeat is not able to ship logs?

 `sudo ls -lai /var/log/app`

```
  95 -rw-r-----  1 root root    11145 Apr  5 17:18 acm.log
  77 -rw-r-----  1 root root    11141 Apr  5 17:17 acm.log.1
  32 -rw-r-----  1 root root     4830 Apr  5 16:04 acm.log.1-1491408301.gz
  76 -rw-r-----  1 root root   131734 Apr  5 17:17 acm.log.2
```

Notice there are 3 uncompressed acm log files. This is a sign that filebeats has not shipped these logs. You can confirm this in the filebeat registry file.

`sudo vi /var/lib/filebeat/registry`

```json
{
	"source": "/var/log/app/acm.log",
	"offset": 86104,
	"FileStateOS": {
		"inode": 75,
		"device": 51824:q
	},
	"timestamp": "2017-04-05T16:10:01.83349184Z",
	"ttl": 259200000000000
}, {
	"source": "/var/log/app/acm.log",
	"offset": 92438,
	"FileStateOS": {
		"inode": 76,
		"device": 51824
	},
	"timestamp": "2017-04-05T17:17:07.026837136Z",
	"ttl": 259200000000000
}, {
	"source": "/var/log/app/acm.log",
	"offset": 0,
	"FileStateOS": {
		"inode": 77,
		"device": 51824
	},
	"timestamp": "2017-04-05T17:17:32.033519831Z",
	"ttl": 259200000000000
}, {
	"source": "/var/log/app/acm.log",
	"offset": 0,
	"FileStateOS": {
		"inode": 95,
		"device": 51824
	},
	"timestamp": "2017-04-05T17:18:37.035608798Z",
	"ttl": 259200000000000
}
```

Filebeat tracks files by inode (`ls -i` to list inodes), and it tracks the position in the file by the offset (in bytes). If the offset does not match the file size of the specified inode, the filebeat has not shipped all logs in the specified file.

In the example above, inode 76 has been paritially shipped, and inodes 77 and 95 have not been shipped at all. Logs will continue to fill the latest inode (95) until a rotation occurs again, and filebeat will continue to track all files.

Notice that inode 75 listed in the filebeat registry does not correspond to a log file currently on disk. Likely this inode had gone through a rotation, was confirmed shipped by filebeat, and then was compressed, at which point its inode changed, likely to 32, corresponding to `acm.log.1-1491408301.gz`. The entry for inode 75 will eventually drop out of the filebeat registry.

If the log partition is running out of space, do not delete these uncompressed files! Instead, detach this instance from the load balancer (ELB) so it will not generate additional logs while you debug what is causing the backpressure. Once logstash is available, and has an available output (you can comment out the elasticsearch output in the logstash config if elasticsearch is not easily recoverable), then filebeat will automatically reconnect and ship its logs.

#### <a name="logging-endpoint-down">Logging Stack - Endpoint unavailability scenarios</a>

**Tags**: *filebeat, logstash, elastic search, elasticsearch, s3, logs*

The logging stack involves the following flow: filebeat -> logstash -> s3 & elasticsearch.

Logstash ships logs to two endpoints (s3 and elasticsearch), and if either one is unavailable, it will ship logs to neither.

In the following two scenarios, different responses should be followed.

A. S3 is down

1. Do nothing: Logs will buffer on the instances, and resume shipping when s3 is available.

B. Elasticsearch is down, and not easily returned to a health state (~within 24 hours)

1. Log into all logstash instances on the respective cluster (common or prodlogs).
2. `sudo vi /etc/logstash/conf.d/indexer.conf`
3. Comment out the elasticsearch output (bottom of file), leave in the s3 output.
4. Save file. Logstash will automatically detect the change to the config and restart the logging pipeline.
5. Logs will ship to s3 but not elasticsearch. Revert change when elasticsearch is in a healthy state.

----

#### <a name="logging-upgrade">Logging Stack - Upgrading versions safely</a>

<https://www.elastic.co/support/matrix#matrix_compatibility>

Now that we're on 5.x versions of ELK, most components are backwards/forwards compatible, with one exception. Kibana requires itself and the entire Elasticsearch cluster to be on the same version.

Our Elasticsearch clusters are comprised of many nodes, which can be running different versions of ES, but this should only occur during the upgrade process, as data will not replicate itself onto older node versions.

Logstash and filebeat can be upgraded at any time, without issue.

For Elasticsearch & Kibana:

1. Build & deploy the Elasticsearch masters. Three should be launched, confirm they have connected to the cluster and have elected one as the official master. The cluster can operate without masters for a period of time, so if they don't connect, you should debug and if not easily fixed, roll back to the previous master launch config.

2. Build & deploy the Elasticsearch coordinator(s). Confirm they have connected to the cluster and logs are still being injested.

3. Build & deploy the Elasticsearch warm nodes. The deploy step won't replace instances, it will only create a launch config.

   a. Double the warm ASG, 2 -> 4.

   b. Confirm new nodes are connected `_cat/nodes`, and shards are balancing `_cat/shards`. Sometimes the data nodes don't mount their storage in time and Elasticsearch doesn't start. SSH in and `sudo service elasticsearch start` if necessary.

   c. When shards are done moving around, scale from 4 -> 3. Cluster will go yellow.

   d. Watch `_cat/health` and `_cat/shards`, wait for shards to rebalance (cluster will go green)

   e. When green scale from 3 -> 2. Cluster will rebalance again and you're good to go.

4. Repeate all steps of #3 except for hot nodes.

5. Build & deploy Kibana. Verifiy connection.

6. Done.

----

#### <a name="logging-launch">Logging Stack - Launching a new stack</a>

Instructions for bringing up a healthy ELK cluster for the first time:

1. Build and deploy all instances

    a. Elasticsearch; 3 masters, 1 coordinator, 2 hot, 2 warm
    b. Logstash
    c. Kibana
    d. Wazuh (optional)

2. SSH into all Elasticsearch instances and confirm Elasticsearch is running. Hot and Warm nodes on first boot sometimes do not initialize their local storage quick enough, and elasticsearch must be started manually.

3. On boot, Search Guard should initialize itself, except in cases above where Elasticsearch wasn't running on all nodes. To manually initialize, run the following command: `sudo /usr/share/elasticsearch/plugins/search-guard-5/tools/sgadmin.sh -cd /usr/share/elasticsearch/plugins/search-guard-5/sgconfig/ -ks /etc/elasticsearch/ssl/develop-virtru-client-keystore.jks -ts /etc/elasticsearch/ssl/develop-truststore.jks -nhnv -cn develop -kspass XXX -tspass XXX --diagnose` (develop cluster example, change naming depending on cluster)

4. The ES Cluster should now be healthy. Confirm Kibana and Logstash are able to connect.

#### <a name="manually-redeploying-buildkite-build-agents">Manually redeploying buildkite build agents</a>

**Tags**: *buildkite, build agents, redeploy, deploy*

Buildkite build agents can be manually re-built here https://buildkite.com/virtru/buildkite-agent-manual-deploy

Build agents should be re-build an re-deployed any time there is a change to the devops-deploy buildkite_build_agent_nodev4 ansible role. After a successful build above, copy the outputted AMI-ID.

Run the following command in devops-deploy/ansible/ to deploy the specified AMI:
``ansible-playbook -vv -u ubuntu --extra-vars '{"ami_id": "<<< INSERT BUILDKITE BUILD AGENT AMI ID >>>", "environment_name": "ami01", "instance_profile_name": "buildkite_build_agent_iam_instance_profile", "region": "us-east-1", "ami_name": "buildkite_build_agent_nodev4", "security_group_lookup_uri": "{{ base_tf_lookup_uri }}#buildkite_build_agents_ec2_security_group", "instance_type": "m3.medium", "version": "manual-run-'$USER'-'$(date -u +%Y-%m-%dT%H-%M-%SZ)'"}' --tags deploy_new_ami --private-key ~/.ssh/ami-key-pair-2016-12-18.pem -i hosts/hosts.ini --ask-vault-pass playbooks/ami.yml``

----

#### <a name="domain-refresh-purge-queue-in-sqs">Domain Refresh Purge Queue in SQS</a>

**Tags**: *sqs, domain refresh, domain worker, queue*

A Domain refresh may have an issue where a sync fails and it needs to be restarted. If this happens you can also consider purging its SQS queue.

The current queue name for production01: `domain-refresh-production01`

From within [SQS in the AWS Console](https://console.aws.amazon.com/sqs/home?region=us-east-1#), filter by the current queue name. Once filtered, select the queue, and from the "Queue Actions" drop-down, click "Purge Queue", and when the modal appears for confirmation, click "Yes, Purge Queue".

----

#### <a name="monitor-cloudant-indexing-activity">Monitor Cloudant Indexing Activity</a>

**Tags**: *cloudant, indexing, monitor*

You can monitor indexing activity and its progress using the below endpoint.

```
curl https://<account>:<password>@<account>.cloudant.com/_active_tasks | jq '.[] | select(.type=="indexer")'
```

So for example, on production, we would use:

```
curl -u virtru-production --pass "<passphrase to your priv key>" --cert /your/path/to/your.pem https://virtru-production.cloudant.com/_active_tasks | jq '.[] | select(.type=="indexer")'
```

If you just pipe the results to `jq` without the select, you'll see all active tasks like view compactions, indexing, etc.

You can read more about the `_active_tasks` here:
https://console.ng.bluemix.net/docs/services/Cloudant/api/active_tasks.html#active-tasks

----

#### <a name="using-aws-role-assumption-from-the-cli-mars">Using AWS Role Assumption from the CLI (MARS)</a>

**Tags**: *aws, mars, sts, iam, awscli*

The MARS infrastructure utilizes functionality of AWS that allows an IAM user
to assume different roles.  To use this from the command line is a simple
matter of correctly setting up your AWS credentials file.

The following example shows how to define a profile in one account using a role
assumption policy from the security account.

        [mars]
        aws_access_key_id = REDACTEDREDACTEDREDA
        aws_secret_access_key = REDACTEDREDACTEDREDACTEDREDACTEDREDACTED

        [mars-develop]
        source_profile = mars
        role_arn = arn:aws:iam::010593031953:role/Administrator

This sets up a "mars" profile using a personal set of AWS keys home in the
"security" account and a "mars-dev" profile that assumes the Administrator role
in the "develop" account.  The names "mars" and "mars-develop" are arbitrary
and can be anything you want.  To use the correct profile with the cli, you can
either pass the `--profile` switch or set an `AWS_PROFILE` environment
variable.


For additional information, refer to the AWS documentation:
<http://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_use_switch-role-cli.html>

----

#### <a name="switching-roles-in-the-aws-console-mars">Switching Roles in the AWS Console (MARS)</a>

**Tags**: *aws, mars, sts, iam*

The MARS infrastructure utilizes functionality of AWS that allows an IAM user
to assume different roles.  To do this from the AWS console, you will need to
know the numeric AWS account ID and role name of the target role.

1. Login to the MARS "security" account at https://virtru-security.signin.aws.amazon.com/console
1. Once logged in, click on your IAM username at the top right
1. In the drop down menu, select "Switch Role"

    ![Switch-Role-Dropdown](.screenshots/switch-role-dropdown.png)

1. On the next page, click the blue "Switch Role" button
1. On the next page, enter the following information and then click the blue "Switch Role" button:
    * Account: account number for the role you need to assume
    * Role: the name of the role you need to assume (e.g. Administrator)
    * Display name: the name of the account for the role you need to assume (e.g. common)

    ![Switch-Role-Form](.screenshots/switch-role-form.png)

1. You should now have assumed the correct role, which will be indicated at the top right

    ![Switch-Role-Indicator](.screenshots/switch-role-indicator.png)


You can find a list of account names and numbers in our Terraform repo:
https://github.com/virtru/devops-terraform/blob/master/vars/variables.tfvars


For additional information, refer to the AWS documentation:
<http://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_use_switch-role-console.html>

----

#### <a name="shudder-resume">Instance that won't terminate/Blocked scaling</a>

**Tags**: *shudder, asg, scale, scaling, terminate, stuck*

Do you have an instance that isn't shutting down?
Is it in an auto scaling group?
Is the instance lifecycle in the autoscaling group "Terminating:Wait"?

If you answered yes to all of the above, and the instance isn't shutting down, you can do the following:

1. SSH to the instance
2. Look at /var/app/shudder/shudder.toml
3. Find the line that starts with `commands`
4. Using sudo run each of the commands on the instance
5. Exit the instance
6. Run the following command, replacing `<application name> <environment name> <instance id>` with the appropriate values: `aws autoscaling complete-lifecycle-action --lifecycle-hook-name autoscale_lifecycle_hook_<application name>_asg_<environment name> --auto-scaling-group-name <application name>_asg_<environment name>--lifecycle-action-result CONTINUE --instance-id <instance id>`

----

`Maximum ApproximateAgeOfOldestMessage of 12216.0 GreaterThanOrEqualToThreshold 12000.0 for QueueName domain-refresh-production01`

#### <a name="domain-worker-maximum-message-age">Domain Worker Maximum Message Age</a>

**Tags**: *domain worker*

The domain worker can sometimes take quite a while with large syncs and it has been observed that sometimes these syncs can hang, requiring the process to be stopped and started again.

##### Monitor names:

- [domain-worker not processing messages](https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#metricsV2:graph=~(metrics~(~(~'AWS*2fSQS~'ApproximateAgeOfOldestMessage~'QueueName~'domain-refresh-production01))~period~300~stat~'Maximum~start~'-PT3H~end~'P0D~yAxis~(left~null~right~null)~title~'domain-worker*20not*20processing*20messages~region~'us-east-1))

##### Determination:

When you get an alarm like one of the above, it means that there are items that have been in the queue longer than the threshold. You can confirm this by viewing the Alarm in CloudWatch via the monitor link above.

##### Resolution:

Terminate any domain_worker instances in environment *production01* via the AWS console.

The auto-scaling group should re-launch healthy instance(s).

##### Addendum

For some domains, the sync process is so overwhelmed that simply restarting the service is not sufficient. Verizon, specifically, has this issue often. To resolve, in addition to the steps above, you will need to check the [Kibana Domain Worker Logs](https://logs-prodlogs-common01.virtru.internal/app/kibana#/discover/Domain-Worker-Message-Process-Logs) to ensure the sync was successfully completed (`message_process_success` for ____@verizon.com), then manually [remove that entry from the SQS queue](https://console.aws.amazon.com/sqs/home?region=us-east-1#view-messages:selected=https://sqs.us-east-1.amazonaws.com/835908307829/domain-refresh-production01;noRefresh=true;prefix=domain$) before restarting the domain worker instance via the ASG as outlined in the Resolution.

----

#### <a name="domain-worker-out-of-memory">Domain Worker Out Of Memory</a>

**Tags**: *domain worker*

The domain worker sometimes runs out of memory, particularly after a large sync (e.g., Verizon). Just restarting the domain worker can lead to it getting in a bad state when it starts back up; therefore, it is recommended to terminate the EC2 instance and allow the ASG to bring up a new one when the out of memory alarm triggers.

##### Monitor names:

- [Memory utilization](https://app.datadoghq.com/monitors#889030)

##### Determination:

When you get an alarm like one of the above specific to the domain worker, it means that a domain worker instance has run out of memory. The instance may not be responsive depending on how severe the lack of free memory is.


##### Resolution:

Scale down the Auto-scaling group for domain worker in production01 to "0" as the desired value. Wait until the scale down is complete, and then update it again to set desired to the previous value or "2".

1. View the auto-scaling groups: https://console.aws.amazon.com/ec2/autoscaling/home?region=us-east-1#AutoScalingGroups:view=details

2. Filter by name: *domain_worker_asg_production01*

3. On the details tab for the above ASG, click *edit*. Set both minimum and desired to "0", and click save.

4. Wait sometime for the ASG to finish, and edit it again and set minimum and desired to "2" (or whatever the previous value was), and click save.

----

#### <a name="block-an-ip-address">Block an IP Address</a>

The process to block an IP address is fairly straight forward. All you have to do is create a NACL rule on the appropriate VPC. There are several things to keep in mind when making a NACL. First, you should always specify the CIDR with a /32, this ensures you only block a single ip. The lower the priority of a NACL rule the sooner its matched, so you'll want to make sure you have a lower priority then the rule allowing 0.0.0.0/0. In the "Allow / Deny" drop down make sure you pick deny.

Here's a sample block in place for the NACL rules associated with the production01 vpc:

![IP-Address-Block](.screenshots/IP-Address-Block.jpg)

----

#### <a name="fortigate-vpn">Add users to the office VPN (fortigate)</a>

The office VPN provides access to the office network via our Fortigate router, and provides users an ip that is whitelisted for other access (Wordpress).

Items accessible from the office network:

* Mac build agents
* Wordpress admin

To connect to the VPN, users must have a user account on the router. To add user accounts, you must have an admin account on the router, be connected to the Fortigate VPN, and login here: https://172.16.0.1:9443/login

![fortigate-add-user](.screenshots/fortigate-add-user.png)

Create New -> Local User -> Username and generate a strong password -> Add contact info, use default options for everything else (no 2FA)

Then provide the username and generated password with the following instructions and screenshots to the user (e-mail encrypted).

Download and install the FortiClient from here:
http://www.forticlient.com/downloads

Open FortiClient and select:
Remote Access - Add a new connection

Remote Gateway: 207.87.28.190

Port: 8443

![fortigate-0-download-client](.screenshots/fortigate-0-download-client.png)

![fortigate-1-RemoteAccess-Addnewconnection](.screenshots/fortigate-1-RemoteAccess-Addnewconnection.png)

![fortigate-2-VPNaccesssetup](.screenshots/fortigate-2-VPNaccesssetup.png)

![fortigate-3-Onconnect](.screenshots/fortigate-3-Onconnect.png)

----

#### <a name="ios-agent-setup">Setup iOS Buildkite Agent</a>

[iOS Buildkite Agent Setup](https://github.com/virtru/virtru-ios-mail/blob/master/.buildkite/osx-buildkite-agent-setup.md)

----
