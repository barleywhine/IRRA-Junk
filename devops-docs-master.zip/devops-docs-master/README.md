# DevOps Docs

### Index
- [DevOps / On-call Runbook](runbook/README.md)
- [DevOps / On-call Handbook](https://docs.google.com/document/d/1wkmBFmyhDOw75BTGdUkSkkInpWo6nQtMvoVJouvj3LM/edit)

### Procedures

Procedural documentation is in the [procedures](procedures/) subdirectory and
is setup to be viewed using [mkdocs](http://mkdocs.readthedocs.io/en/stable/)
by running `mkdocs serve` at the root of this repository and then browsing to
[http://localhost:8000](http://localhost:8000).
